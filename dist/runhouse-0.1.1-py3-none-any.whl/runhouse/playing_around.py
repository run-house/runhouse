import time
import sys
from runhouse.utils.file_utils import create_directory


# Mock python job

def run_stuff(*args, **kwargs):
    print("args in func", args)
    print("creating directory")
    create_directory('sample_dir')
    time.sleep(5)
    print("Finished running stuff")


if __name__ == '__main__':
    main_args = sys.argv[1:]
    run_stuff(*main_args)
